package com.SpringBootRestAPI.example.Exception;

import java.time.LocalDateTime;
/**
 * Module: SpringExchangeRateApi <br>
 * 
 * The class ExceptionResponse used to provide custom exception message.
 * 
 * @author sangmeshwar
 */
public class ExceptionResponse {
	private String message;
	private LocalDateTime dateTime;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
}
