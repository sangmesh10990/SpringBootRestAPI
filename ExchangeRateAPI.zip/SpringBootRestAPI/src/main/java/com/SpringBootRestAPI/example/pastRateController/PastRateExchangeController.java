package com.SpringBootRestAPI.example.pastRateController;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.LinkedHashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.SpringBootRestAPI.example.Exception.GlobalDefaultExceptionHandler;

/**
 * Module: SpringExchangeRateApi <br>
 * 
 * The class PastRateExchangeController used to fetch past exchange data.
 * 
 * @author sangmeshwar
 */

@RestController
@ResponseBody
public class PastRateExchangeController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PastRateExchangeController.class);

	/* Get values from properties file */
	@Value("${past.requiredMonth}")
	private int requiredMonth;
	@Value("${rest.api.io.currenturl}")
	private String currentRateURL;
	@Value("${rest.api.io.base}")
	private String base;
	@Value("${rest.api.io.symbols}")
	private String symbols;
	@Value("${rest.api.io.baseURL}")
	private String baseURL;

	// get past month date exchange rate
	@SuppressWarnings("unchecked")
	@GetMapping("pastRates")
	public ModelAndView getPastExchangeRate() {
		LOGGER.info("Sending Request to Past Rate API");

		ModelAndView mv = new ModelAndView();
		mv.setViewName("pastData");
		ResponseEntity<Object> response = null;

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			JSONArray jsonArray = new JSONArray();
			JSONArray monthArray = new JSONArray();

			// Calling API for get past Exchange Rates
			for (int i = requiredMonth; i > 0; i--) {
				JSONObject jsonObj = new JSONObject();
				String date = LocalDate.now().minusMonths(i).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				response = restTemplate.exchange(baseURL + date + "?base=" + base + "&symbols=" + symbols,
						HttpMethod.GET, entity, Object.class);
				LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) response.getBody();
				LocalDate currentDate = LocalDate.parse(map.get("date").toString());
				Month month = currentDate.getMonth();
				int year = currentDate.getYear();
				jsonObj.put(month.toString() + "-" + year, map.get("rates"));
				jsonArray.put(jsonObj);
				mv.addObject("data", jsonArray);
				monthArray.put(month.toString());

			}
			// Adding data to model to display dynamic data on Pages
			mv.addObject("base", base);
			mv.addObject("symbols",
					String.join(",", Arrays.asList(symbols.split("\\s*,\\s*"))).replaceAll("([^,]+)", "\"$1\""));
			mv.addObject("requiredMonth", requiredMonth);
		} catch (Exception ex) {
			LOGGER.debug("Error occurred");
			/* Throwing Custom exception */
			throw new GlobalDefaultExceptionHandler();
		}
		LOGGER.info("Call End to Past API");
		return mv;
	}
}
