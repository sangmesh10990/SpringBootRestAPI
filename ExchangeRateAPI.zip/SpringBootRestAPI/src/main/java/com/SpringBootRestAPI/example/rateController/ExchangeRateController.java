package com.SpringBootRestAPI.example.rateController;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

/**
 * Module: SpringExchangeRateApi <br>
 * 
 * The class ExchangeRateController used to map client request
 * 
 * @author sangmeshwar
 */

@RestController
@ResponseBody
public class ExchangeRateController implements ErrorController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExchangeRateController.class);

	@Value("${rest.api.io.currenturl}")
	private String currentRateURL;
	@Value("${rest.api.io.pastRateURL1}")
	private String pastRateURL1;
	@Value("${rest.api.io.pastRateURL2}")
	private String pastRateURL2;
	@Value("${rest.api.io.pastRateURL3}")
	private String pastRateURL3;
	@Value("${rest.api.io.pastRateURL4}")
	private String pastRateURL4;
	@Value("${rest.api.io.pastRateURL5}")
	private String pastRateURL5;
	@Value("${rest.api.io.pastRateURL6}")
	private String pastRateURL6;

	// get current date exchange rate
	@SuppressWarnings("unchecked")
	@GetMapping("currentRate")
	public ModelAndView getCurrentExchangeRate() {

		LOGGER.info("Sending Request to API");

		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		ResponseEntity<Object> response = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			// headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

			response = restTemplate.exchange(currentRateURL, HttpMethod.GET, entity, Object.class);

			LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) response.getBody();
			System.out.println(map.get("rates"));
			ArrayList<Object> list = new ArrayList<Object>();

			LocalDate currentDate = LocalDate.parse(map.get("date").toString());

			// Get month from date
			Month month = currentDate.getMonth();

			// Get year from date

			list.add(map.get("rates"));
			// list.add(month);
			mv.addObject("obj", list);
			mv.addObject("month", month);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		LOGGER.info("Current Rate API Call end");
		return mv;
	}

//get past dates
	@SuppressWarnings("unchecked")
	@GetMapping("pastRates")
	public ModelAndView getPastExchangeRate() {

		LOGGER.info("Sending Request to Past Rate API");

		ModelAndView mv = new ModelAndView();
		mv.setViewName("pastData");
		ResponseEntity<Object> response = null;

		ArrayList<Object> allList = new ArrayList<Object>();
		HashMap<String, Object> mapAll = new HashMap<String, Object>();

		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();

			headers.add("user-agent",
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
			HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
			/* 1St month */
			response = restTemplate.exchange(pastRateURL1, HttpMethod.GET, entity, Object.class);

			LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) response.getBody();
			System.out.println(map.get("rates"));
			ArrayList<Object> list = new ArrayList<Object>();
			LocalDate currentDate = LocalDate.parse(map.get("date").toString());
			// Get month from date
			Month month = currentDate.getMonth();
			// Get year from date
			list.add(map.get("rates"));
			mv.addObject("data1", list);
			mv.addObject("month1", month);

			mapAll.put(month.toString(), map.get("rates"));

			// get Another next Month data (API not supporting aggregated data of past
			// months so need to Consume same API with new Dates)

			/* 2nd month */
			response = restTemplate.exchange(pastRateURL2, HttpMethod.GET, entity, Object.class);

			map = (LinkedHashMap<String, Object>) response.getBody();

			list = new ArrayList<Object>();
			currentDate = LocalDate.parse(map.get("date").toString());
			// Get month from date
			month = currentDate.getMonth();
			// Get year from date
			list.add(map.get("rates"));
			mv.addObject("data2", list);
			mv.addObject("month2", month);

			mapAll.put(month.toString(), map.get("rates"));

			/* 3rd month */
			response = restTemplate.exchange(pastRateURL3, HttpMethod.GET, entity, Object.class);

			map = (LinkedHashMap<String, Object>) response.getBody();

			list = new ArrayList<Object>();
			currentDate = LocalDate.parse(map.get("date").toString());
			// Get month from date
			month = currentDate.getMonth();
			// Get year from date
			list.add(map.get("rates"));
			mv.addObject("data3", list);
			mv.addObject("month3", month);

			mapAll.put(month.toString(), map.get("rates"));

			/* 4th month */
			response = restTemplate.exchange(pastRateURL4, HttpMethod.GET, entity, Object.class);

			map = (LinkedHashMap<String, Object>) response.getBody();

			list = new ArrayList<Object>();
			currentDate = LocalDate.parse(map.get("date").toString());
			// Get month from date
			month = currentDate.getMonth();
			// Get year from date
			list.add(map.get("rates"));
			mv.addObject("data4", list);
			mv.addObject("month4", month);

			mapAll.put(month.toString(), map.get("rates"));

			/* 5th month */
			response = restTemplate.exchange(pastRateURL5, HttpMethod.GET, entity, Object.class);

			map = (LinkedHashMap<String, Object>) response.getBody();

			list = new ArrayList<Object>();
			currentDate = LocalDate.parse(map.get("date").toString());
			// Get month from date
			month = currentDate.getMonth();
			// Get year from date
			list.add(map.get("rates"));
			mv.addObject("data5", list);
			mv.addObject("month5", month);
			mapAll.put(month.toString(), map.get("rates"));

			/* 6th month */
			response = restTemplate.exchange(pastRateURL6, HttpMethod.GET, entity, Object.class);

			map = (LinkedHashMap<String, Object>) response.getBody();

			list = new ArrayList<Object>();
			currentDate = LocalDate.parse(map.get("date").toString());
			// Get month from date
			month = currentDate.getMonth();
			// Get year from date
			list.add(map.get("rates"));
			mv.addObject("data6", list);
			mv.addObject("month6", month);
			mapAll.put(month.toString(), map.get("rates"));
			allList.add(mapAll);
			mv.addObject("allList", allList);

		} catch (Exception ex) {
			LOGGER.debug("Error occurred");
			ex.printStackTrace();

		}
		LOGGER.info("Call End to Past API");
		return mv;
	}

	@RequestMapping("/error")
	public ModelAndView handleError(HttpServletRequest request) {
		LOGGER.info("Error occurred Sending to Error Page");
		ModelAndView mv = new ModelAndView();
		mv.setViewName("error");

		Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		if (status != null) {
			Integer statusCode = Integer.valueOf(status.toString());

			if (statusCode == HttpStatus.NOT_FOUND.value()) {
				// return "error-404";
				mv.addObject("ErrorObj", "Page Not Found " + HttpStatus.NOT_FOUND.value());
				return mv;
			} else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
				// return "error-500";
				mv.addObject("ErrorObj", "Internal Server Error " + HttpStatus.NOT_FOUND.value());
				return mv;
			}
		}
		return mv;
	}

	@Override
	public String getErrorPath() {
		return null;
	}
}
