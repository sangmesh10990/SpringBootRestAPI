package com.SpringBootRestAPI.example.Exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
/**
 * Module: SpringExchangeRateApi <br>
 * 
 * The class GlobalDefaultExceptionHandler used to handle global exception.
 * 
 * @author sangmeshwar
 */
@ControllerAdvice
public class GlobalDefaultExceptionHandler extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(GlobalDefaultExceptionHandler.class);

}
