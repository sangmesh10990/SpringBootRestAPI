package com.SpringBootRestAPI.example.Exception;

import java.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
/**
 * Module: SpringExchangeRateApi <br>
 * 
 * The class CustomizedExceptionHandling used to handle global exception.
 * 
 * @author sangmeshwar
 */
@ControllerAdvice
public class CustomizedExceptionHandling extends ResponseEntityExceptionHandler {

	/* handling Custom exception when user try to fetch invalid currency rate */
	@ExceptionHandler(GlobalDefaultExceptionHandler.class)
	public ModelAndView handleExceptions(GlobalDefaultExceptionHandler exception, WebRequest webRequest) {
		final Logger LOGGER = LoggerFactory.getLogger(CustomizedExceptionHandling.class);

		LOGGER.info("Error occurred Sending to Error Page");

		ModelAndView mv = new ModelAndView();
		mv.setViewName("error");
		mv.addObject("ErrorObj", "Internal Server Error " + HttpStatus.NOT_FOUND.value());

		ExceptionResponse response = new ExceptionResponse();
		response.setDateTime(LocalDateTime.now());
		response.setMessage("Not found");
		ResponseEntity<Object> entity = new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		return mv;

	}
}
